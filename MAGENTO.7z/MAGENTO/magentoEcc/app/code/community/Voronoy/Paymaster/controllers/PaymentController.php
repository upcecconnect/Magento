<?php

class Voronoy_Paymaster_PaymentController extends Mage_Core_Controller_Front_Action
{
    public function redirectAction()
    {
        $block = $this->getLayout()->createBlock('voronoy_paymaster/method_form', 'paymaster_redirect',
            array('template' => 'paymaster/redirect.phtml'));
        $this->getResponse()->setBody($block->toHtml());
    }

    /**
     * http://opencart2.shevernova-decor.com.ua/paymaster/payment/callback
     */
    public function callbackAction($request)
    {
        $requestData = Mage::app()->getRequest()->getParams();
        $request = Mage::getModel('voronoy_paymaster/request');
        $request->setData($requestData);

        $order = $request->getOrder();
        if (false === $this->checkSignature($requestData)){
            echo "MerchantID = " . $requestData['MerchantID'] . "\n";
            echo "TerminalID = " . $requestData['TerminalID'] . "\n";
            echo "OrderID = " . $requestData['OrderID'] . "\n";
            echo "Currency = " . $requestData['CurrencyID'] . "\n";
            echo "TotalAmount = " . $requestData['TotalAmount'] . "\n";
            echo "XID = " . $requestData['XID'] . "\n";
            echo "PurchaseTime = " . $requestData['PurchaseTime'] . "\n";
            echo "Response.action= reverse \n";
            echo "Response.reason= something goes wrong \n";
            echo "Response.forwardUrl=  \n";
            return;
        }

        if ($requestData['TranCode'] === '000') {
            $order->setData('state', "complete");
            $order->setStatus("complete");
            $history = $order->addStatusHistoryComment('Order was set to Complete by our automation tool.', false);
            $history->setIsCustomerNotified(false);
            $order->save();
        } else {
            $order->setData('state', "canceled");
            $order->setStatus("canceled");
            $history = $order->addStatusHistoryComment('Order was set to cancel by our automation tool.', false);
            $history->setIsCustomerNotified(false);
            $order->save();
        }

        echo "MerchantID = " . $requestData['MerchantID'] . "\n";
        echo "TerminalID = " . $requestData['TerminalID'] . "\n";
        echo "OrderID = " . $requestData['OrderID'] . "\n";
        echo "Currency = " . $requestData['CurrencyID'] . "\n";
        echo "TotalAmount = " . $requestData['TotalAmount'] . "\n";
        echo "XID = " . $requestData['XID'] . "\n";
        echo "PurchaseTime = " . $requestData['PurchaseTime'] . "\n";
        echo "Response.action= approve \n";
        echo "Response.reason= ok \n";
        echo "Response.forwardUrl=  \n";

    }

    private function checkSignature(array $requestData)
    {
        $MerchantID = $requestData['MerchantID'];
        $TerminalID = $requestData['TerminalID'];
        $OrderID = $requestData['OrderID'];
        $PurchaseTime = $requestData['PurchaseTime'];
        $TotalAmount = $requestData['TotalAmount'];
        $CurrencyID = $requestData['Currency'];
        $XID = $requestData['XID'];
        $SD = $requestData['SD'];
        $TranCode = $requestData['TranCode'];
        $ApprovalCode = $requestData['ApprovalCode'];
        $signature = $requestData["Signature"];


        $data = $MerchantID . ";" . $TerminalID . ";" . $PurchaseTime . ";" . $OrderID . ";" . $XID . ";" . $CurrencyID . ";" . $TotalAmount . ";;" . $TranCode . ";" . $ApprovalCode.";";
        $basepath = Mage::getBaseDir('media');
        $crtid = openssl_pkey_get_public(file_get_contents($basepath .'/keys/work-server.pub'));

        $verify_status = openssl_verify($data, $signature, $crtid);
        openssl_free_key($crtid);

        return $verify_status;
    }

    public function resultAction()
    {
        $requestData = Mage::app()->getRequest()->getParams();
        $request = Mage::getModel('voronoy_paymaster/request');
        $request->setData($requestData);

        if ($request->getData(Voronoy_Paymaster_Model_Request::FIELD_NAME_PREREQUEST)) {
            $this->_preRequest($request);
        } else {
            $this->_paymentNotify($request);
        }
    }

    /**
     * @param Voronoy_Paymaster_Model_Request $request
     */
    protected function _paymentNotify($request)
    {
        $order = $request->getOrder();
        $order->getPayment()->getMethodInstance()->debugData($request->getData());
        try {
            if (!$request->validateHash($request->getData(Voronoy_Paymaster_Model_Request::FIELD_NAME_HASH))) {
                Mage::throwException(Mage::helper('voronoy_paymaster')->__('Invalid Hash'));
            }
            if ($order->canInvoice()) {
                $invoice = $order->prepareInvoice();
                $invoice->register();
                $transactionSave = Mage::getModel('core/resource_transaction')
                    ->addObject($invoice)
                    ->addObject($invoice->getOrder());

                $transactionSave->save();

                $order->setStatus('success');
                $order->addStatusHistoryComment(
                    Mage::helper('voronoy_paymaster')->__('Payment confirmed by eCommerceConnect'));
                $order->save();
            }
        } catch (Exception $e) {
            Mage::logException($e);
            $this->getResponse()->setHeader('HTTP/1.1', '503 Service Unavailable')->sendResponse();
        }
    }

    /**
     * @param Voronoy_Paymaster_Model_Request $request
     */
    protected function _preRequest($request)
    {
        $order = $request->getOrder();
        $paymentMethod = $order->getPayment()->getMethodInstance();
        $paymentMethod->debugData($request->getData());
        if ($paymentMethod->validateRequest($request)) {
            echo 'YES';
            exit;
        }
    }

    public function successAction()
    {
        Mage::getSingleton('checkout/session')->getQuote()->setIsActive(false)->save();
        $this->_redirect('checkout/onepage/success', array('_secure' => true));
    }

    public function failAction()
    {
        $session = Mage::getSingleton('checkout/session');
        if ($session->getLastRealOrderId()) {
            $order = Mage::getModel('sales/order')->loadByIncrementId($session->getLastRealOrderId());
            $quote = Mage::getModel('sales/quote')->load($order->getQuoteId());
            if ($order->getId()) {
                $order->cancel()->save();
            }
            Mage::helper('voronoy_paymaster')->restoreQuote($quote);
        }

        $session->addError(Mage::helper('voronoy_paymaster')->__('Payment was fail. Please try again later.'));
        $this->_redirect('checkout/cart');
    }
}
